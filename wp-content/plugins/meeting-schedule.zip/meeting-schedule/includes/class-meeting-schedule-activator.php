	<?php

/**
 * Fired during plugin activation
 *
 * @link       http://www.castrocountryclub.org
 * @since      1.0.0
 *
 * @package    Meeting_Schedule
 * @subpackage Meeting_Schedule/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Meeting_Schedule
 * @subpackage Meeting_Schedule/includes
 * @author     Mario Hernandez <mario.hernandez@gmail.com>
 */
class Meeting_Schedule_Activator {



	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
		require_once plugin_dir_path( __FILE__ ) . 'class-meeting-schedule-data.php';

		$activator = new Meeting_Schedule_Data();
		$activator->createTables();

	}




}
