<?php



/**
 * Fired during plugin activation
 *
 * @link       http://www.castrocountryclub.org
 * @since      1.0.0
 *
 * @package    Meeting_Schedule
 * @subpackage Meeting_Schedule/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Meeting_Schedule
 * @subpackage Meeting_Schedule/includes
 * @author     Mario Hernandez <mario.hernandez@gmail.com>
 */
class Meeting_Schedule_Data {

	protected $charset_collate;
	protected $meetingTypesTableName;
	protected $meetingsTableName;

	/**
	 * Initialize the collections used to maintain the actions and filters.
	 *
	 * @since    1.0.0
	 */
	public function __construct() {
		global $wpdb;
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );	

		$this->charset_collate = $wpdb->get_charset_collate();
		$this->meetingTypesTableName = $wpdb->prefix . "ccc_meeting_types";
		$this->meetingsTableName = $wpdb->prefix . "ccc_meetings";

	}

	public function createTables(){
		global $wpdb;
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );		
		error_log('Meeting_Schedule_Activator->createTables');

		// create meeting type table"
		$createMeetingTypesTable = "CREATE TABLE $this->meetingTypesTableName  ( 
			id int(10) NOT NULL AUTO_INCREMENT , 
			short_name CHAR(6) NOT NULL , 
			full_name VARCHAR(60) NOT NULL , 
			url VARCHAR(256) NOT NULL , 
			color CHAR(7) NOT NULL , 
			PRIMARY KEY (id) 
			) $this->charset_collate;";

		dbDelta( $createMeetingTypesTable );

		// create meetings table
		$createMeetingsTable = "CREATE TABLE $this->meetingsTableName  ( 
			id int(10) NOT NULL AUTO_INCREMENT
			name VARCHAR(60) NOT NULL , 
			meeting_type_id INT NOT NULL , 
			start_time TIME NOT NULL , 
			end_time TIME NOT NULL , 
			day_of_week INT NOT NULL , 
			details VARCHAR(256) NULL,
			FOREIGN KEY  (meeting_type_id) REFERENCES $this->meetingTypesTableName(id),
			PRIMARY KEY (id)
		) $this->charset_collate;";

		
		dbDelta( $createMeetingsTable );
	}

	/**
	*
	*	Function to get all the current meetings with their associated meeting abbreviations and color coding
	*
	**/
	public function getMeetingsWithLegends(){
		global $wpdb;
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		//error_log("schedule-data: getMeetingsWithLegends");

		
		$sql = "select m.id as id, mt.id as mt_id, name, color, short_name as meeting_type, start_time, end_time, day_of_week, details from $this->meetingsTableName m, $this->meetingTypesTableName mt where m.meeting_type_id = mt.id order by 
			day_of_week, start_time;";

		$result = $wpdb->get_results($sql);

		
		//error_log("getMeetingsWithLegends:" . print_r($result, true));

		return $result;

	}

	/**
	*
	*	Function to get all the possible meeting types
	*
	**/
	public function getMeetingTypes(){
		global $wpdb;
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		//error_log("schedule-data: getMeetingTypes");

		
		$sql = "select * from $this->meetingTypesTableName;";

		$result = $wpdb->get_results($sql);

		
		//error_log("getMeetingTypes: " . print_r($result, true));

		return $result;

	}

	public function insertMeetingType($input){
		global $wpdb;
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );


		$valueArray = array( 
				'short_name' => $input['short_name'], 
				'full_name' => $input['full_name'] ,
				'url' => $input['url'], 
				'color' => $input['color']
			);

		//error_log(" updateMeetingType: array is " . print_r($valueArray, true));

		$result = $wpdb->insert( $this->meetingTypesTableName , $valueArray );


		return $result;		
	}

	public function insertMeetingEntry($input){
		global $wpdb;
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );


		$valueArray = array( 
				'name' => $input['name'], 
				'start_time' => $input['startTime'] ,
				'end_time' => $input['endTime'], 
				'details' => $input['details'],
				'meeting_type_id' => $input['meetingTypeId'], 
				'day_of_week' => $input['day']
			);

		//error_log(" updateMeetingEntry: array is " . print_r($valueArray, true));

		$result = $wpdb->insert( $this->meetingsTableName , $valueArray );


		return $result;		
	}
	public function updateMeetingType($input){
		global $wpdb;
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );


		$valueArray = array( 
				'short_name' => $input['short_name'], 
				'full_name' => $input['full_name'] ,
				'url' => $input['url'], 
				'color' => $input['color']
			);

		$whereArray = array (
				'id' => $input[id]
			);
		//error_log(" updateMeetingType: array is " . print_r($valueArray, true));

		$result = $wpdb->update( $this->meetingTypesTableName , $valueArray , $whereArray);


		return $result;		
	}

	public function updateMeetingEntry($input){
		global $wpdb;
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );


		$valueArray = array( 
				'name' => $input['name'], 
				'start_time' => $input['startTime'] ,
				'end_time' => $input['endTime'], 
				'details' => $input['details'],
				'meeting_type_id' => $input['meetingTypeId'], 
				'day_of_week' => $input['day']
			);

		$whereArray = array (
				'id' => $input['id']
			);
		//error_log(" updateMeetingType: array is " . print_r($input, true));

		$result = $wpdb->update( $this->meetingsTableName , $valueArray , $whereArray);


		return $result;		
	}
	public function deleteMeetingType($input){
		global $wpdb;
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );


		$result = $wpdb->delete($this->meetingTypesTableName, array( 'id' => $input));
		//error_log("deleteMeetingType: cont, result is " . $result);

		if(!isset($result)  || $result==null){
			error_log("couldn't delete row id " .$input . ", exception follows: " . $wpdb->last_error);
			$result = array ( 'error' => "Cannot delete a fellowship with meetings in the schedule. Please delete all meetings first. ");
		}
		return $result;
	}

	public function deleteMeetingEntry($input){
		global $wpdb;
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );


		$result = $wpdb->delete($this->meetingsTableName, array( 'name' => $input));
		//error_log("deleteMeetingEntry: cont, result is " . $result);

		if(!isset($result)  || $result==null){
			error_log("couldn't delete row id " .$input . ", exception follows: " . $wpdb->last_error);
			$result = array ( 'error' => "Cannot delete this meeting, call system admin ");
		}
		return $result;
	}	

}