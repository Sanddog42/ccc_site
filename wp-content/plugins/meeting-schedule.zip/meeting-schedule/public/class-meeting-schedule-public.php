<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       http://www.castrocountryclub.org
 * @since      1.0.0
 *
 * @package    Meeting_Schedule
 * @subpackage Meeting_Schedule/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Meeting_Schedule
 * @subpackage Meeting_Schedule/public
 * @author     Mario Hernandez <mario.hernandez@gmail.com>
 */
class Meeting_Schedule_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
     *
     *
     */
    protected $dataManager;
    protected $meetingTypes;
    protected $meetings;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

		require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-meeting-schedule-data.php';
        $this->dataManager = new Meeting_Schedule_Data();

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Meeting_Schedule_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Meeting_Schedule_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/meeting-schedule-public.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Meeting_Schedule_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Meeting_Schedule_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/meeting-schedule-public.js', array( 'jquery' ), $this->version, false );

	}

	public function displayMeetings(){

		$this->meetingTypes = stripslashes_deep($this->dataManager->getMeetingTypes());
    	$this->meetings = stripslashes_deep($this->dataManager->getMeetingsWithLegends());

		error_log("!!!!success called the display meeting with short code");

    	///error_log("admin.display_plugin_setup_page.meetingTypes:" . print_r($this->meetingTypes, true));
    	//error_log("admin.display_plugin_setup_page.meetings:" . print_r($this->meetings, true));
        include_once 'partials/meeting-schedule-public-display.php';

	}

}
