<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       http://www.castrocountryclub.org
 * @since      1.0.0
 *
 * @package    Meeting_Schedule
 * @subpackage Meeting_Schedule/public/partials
 */

$dayArray = array('Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday');
?>


        <?php


            $lastDay = "";
            $loadedDiv = "";
            foreach ($this->meetings as $meeting) {
                $day = $dayArray[$meeting->day_of_week];

                if($lastDay != $day){ // if the last day isn't the current day then need to start a day label
					echo($loadedDiv);
					echo('<div class="scheduleDay">' . $day . '</div> ');
					echo('<div class="scheduleEvents"> ');
					$loadedDiv = '</div>';
				}
                echo('  <div class="scheduleEvent" style="border-left-color:' . stripslashes($meeting->color ) . ';">');
				echo('    <div class="eventLabel">' . stripslashes($meeting->meeting_type) . '</div>');
				echo('    <div class="eventValue">' . stripslashes( $meeting->name ) . '</div>');
				echo('    <div class="eventLabel">Time</div>');
				echo('    <div class="eventValue">' . stripslashes( $meeting->start_time ) . '-' . stripslashes( $meeting->end_time ) . '</div>');
				if( $meeting->details ){
					echo('    <div class="eventDescription">' . stripslashes( $meeting->details ) . '</div>') ;

				}
				echo('  </div>');

				$lastDay = $day;

            }
            echo('</div>');
        ?>


<!-- This file should primarily consist of HTML with a little bit of PHP. -->
	<br/>
	<h1 class="entry-title">Fellowship Details</h1>
        <table title="Fellowships" style="text-align: left; ">
            <tr>
            	<th> </th>
                <th>Fellowship</th>
                <th>Abbr</th>
                <th>Link</th>
                
            </tr>


        <?php
            // output all the fellowship types
            foreach ($this->meetingTypes as $type) {
                echo("<tr style='border-right: 1px solid black;''>");
                echo("<td id='" .$type->id ."_color'style='background-color: $type->color'>&nbsp</td>\n");
                echo("<td id='" .$type->id ."_full_name'>$type->full_name </td>");
                echo("<td id='" .$type->id ."_short_name'>$type->short_name</td>");
                echo("<td id='" .$type->id ."_url'><a href='$type->url'>$type->url</a></td>");
                echo("</tr>");
            }
        ?>
        </table>
